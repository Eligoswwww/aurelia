# Placeholder for payments handler
