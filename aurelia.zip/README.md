# Aurelia Telegram Bot

This is a scalable, secure Telegram bot project.
